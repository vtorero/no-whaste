import { Component } from '@angular/core';

@Component({
  selector: 'app-redneuronal',
  templateUrl: './redneuronal.component.html',
  styleUrls: ['./redneuronal.component.css']
})
export class RedneuronalComponent {

}
