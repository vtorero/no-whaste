import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComparaModelosComponent } from './compara-modelos.component';

describe('ComparaModelosComponent', () => {
  let component: ComparaModelosComponent;
  let fixture: ComponentFixture<ComparaModelosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComparaModelosComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ComparaModelosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
