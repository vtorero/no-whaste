import { Component } from '@angular/core';

@Component({
  selector: 'app-editarventa',
  templateUrl: './editarventa.component.html',
  styleUrls: ['./editarventa.component.css']
})
export class EditarventaComponent {

}
