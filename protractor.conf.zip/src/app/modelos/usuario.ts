export class Usuario {
    constructor(
        public id: string,
        public nombre: string,
        public correo: string,
        public estado: string,
        public clase:string
    ){}
}


