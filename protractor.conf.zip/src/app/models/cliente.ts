export class Cliente {
    constructor(
        public id:number,
        public nombre:string,
        public apellido:string,
        public direccion:string,
        public telefono:string,
        public num_documento:string
        ){}
}
