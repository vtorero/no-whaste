import { PaginatorEspanol } from './paginator-espanol';

describe('PaginatorEspanol', () => {
  it('should create an instance', () => {
    expect(new PaginatorEspanol()).toBeTruthy();
  });
});
