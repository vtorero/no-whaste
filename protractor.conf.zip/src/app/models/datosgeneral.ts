export class Datosgeneral {
    constructor(
    public empresa:string,
    public correo:string,
    public nombres:string,
    public telefono:string,
    public sociedad:string,
    public paginas:string,
    public rut:string,
    public domicilio:string,
    public calle:string,
    public numero:string,
    public ciudad:string,
    public pais:string,
    public confinanzas:string,
    public tlffinanzas:string,
    public correofinan:string,
    public medios:string
    ){}
}
