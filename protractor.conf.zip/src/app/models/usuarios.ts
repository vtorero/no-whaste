export class Usuarios {
    id: number;
    nombre: string;
    apellido: string;
    nacionalidad: string;
    edad:number;
}