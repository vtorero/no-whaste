export class Movimiento {
    constructor(
        public codigo:string,
        public unidad:string,
        public operacion:string,
        public cantidad:number,
        public usuario:string
        ){}
    }