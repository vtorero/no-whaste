export class Proveedor {
    constructor(
        public codigo:string,
        public razon_social:string,
        public direccion:string,
        public departamento:string,
        public provincia:string,
        public distrito:string,
        public telefono:string,
        public num_documento: string,
        public estado:string
    ){}
}
