import { Impresiones } from './impresiones';

describe('Impresiones', () => {
  it('should create an instance', () => {
    expect(new Impresiones()).toBeTruthy();
  });
});
