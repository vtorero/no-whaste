export class Transportista {
constructor(
public tipoDoc:string,
public numDoc:string,
public rznSocial:string,
public placa:string,
public choferTipoDoc:string,
public choferDoc:string,
){}
}
