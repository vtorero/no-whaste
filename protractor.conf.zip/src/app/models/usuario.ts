export class Usuario{
    constructor(
        public usuario:string,
        public password:string,
    ){}
}