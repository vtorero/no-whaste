export class Datos{
        public dimensionad_exchange_device_category:string;
        public total:string;

}
