import { Datosgeneral } from './datosgeneral';

describe('Datosgeneral', () => {
  it('should create an instance', () => {
    expect(new Datosgeneral()).toBeTruthy();
  });
});
