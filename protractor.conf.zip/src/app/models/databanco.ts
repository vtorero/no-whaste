export class Databanco {
    constructor(
        public empresa:string,
        public entidad:string,
        public beneficiario:string,
        public persona:string,
        public dom_entidad:string,
        public ciudad:string,
        public sucursal:string,
        public tipocuenta:string,
        public numerocta:string,
        public aba:string,
        public swift:string,
        public contactobco:string,
        public tlfcontacto:string,
        public bancointer:string,
        public abainter:string,
        public condicion:string
        ){}
}
