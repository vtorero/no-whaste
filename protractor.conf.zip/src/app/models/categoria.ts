export class Categoria {
    constructor(
        public nombre:string
        ){}
}
