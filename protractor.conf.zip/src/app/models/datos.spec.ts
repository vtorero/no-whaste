import { Datos } from './datos';

describe('Datos', () => {
  it('should create an instance', () => {
    expect(new Datos()).toBeTruthy();
  });
});
