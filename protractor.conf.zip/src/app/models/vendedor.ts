export class Vendedor {
    constructor(
    id: number,
    nombre: string,
    apellidos: string,
    dni: string,
    razon_social: string,
    ruc: string,
    fecha:string
    ){}
}