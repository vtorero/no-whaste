export class Impresiones {
    columnad_exchange_estimated_revenue: number;
    columnad_exchange_impressions: number;
    dimensiondate: Date;
    
}
