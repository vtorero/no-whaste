export class Guiadetalle {
    constructor(
        public id: string,
        public codigo: string,
        public unidad: string,
        public descripcion: string,
        public cantidad: number,
){}
}