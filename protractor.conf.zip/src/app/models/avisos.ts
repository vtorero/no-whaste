export class Avisos {
    constructor(
        public id:number,
        public id_producto:number,
        public num_comprobante:string,
        public nombre:string,
        public fecha_produccion:string,
        public dias:number
        ){}
}
