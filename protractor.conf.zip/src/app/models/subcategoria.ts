export class Subcategoria {
    constructor(
        public id:number,
        public id_categoria:number,
        public categoria:string,
        public nombre:string
        ){}
}
