export class Boletadetalle {
    constructor( 
        public id:number,
        public descripcion:string,
        public cantidad: number,
        public precio:number

    ){}
}