export class Cuota {
    constructor(
        public moneda: string,
        public monto: number,
        public fechaPago: Date,

){}
}