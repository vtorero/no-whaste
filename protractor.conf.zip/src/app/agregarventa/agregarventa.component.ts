import { Component } from '@angular/core';

@Component({
  selector: 'app-agregarventa',
  templateUrl: './agregarventa.component.html',
  styleUrls: ['./agregarventa.component.css']
})
export class AgregarventaComponent {

}
